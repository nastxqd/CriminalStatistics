package com.example.criminal3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Criminal3Application {

	public static void main(String[] args) {
		SpringApplication.run(Criminal3Application.class, args);
	}

}
